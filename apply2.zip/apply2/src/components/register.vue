<template>
  <div class='bgWhite'>
    <el-container>
      <el-main>
        <!-- 第一步 -->
        <div class='formBoxReg'>
          <img alt src='./../assets/2.png' class='img1' />
          <h1>注册</h1>
          <h4>请填写您的资料信息</h4>
          <el-form :model='form' :rules='rules' ref='form'>
            <ul class='formListReg'>
              <li>
                <h5>姓名</h5>
                <el-form-item prop='name'>
                  <el-input
                    type='text'
                    v-model='form.name'
                    placeholder='请输入来访人员姓名'
                    oninput='if(value.length>10)value=value.slice(0,10)'
                    class='formText'
                  ></el-input>
                </el-form-item>
              </li>
              <li>
                <h5>单位名称</h5>
                <el-form-item prop='unit'>
                  <el-input
                    v-model='form.unit'
                    type='text'
                    placeholder='请输入来访人员单位名称'
                    oninput='if(value.length>20)value=value.slice(0,20)'
                    class='formText'
                  ></el-input>
                </el-form-item>
              </li>
              <li>
                <h5>身份证</h5>
                <el-form-item prop='id'>
                  <el-input
                    v-model='form.id'
                    placeholder='请输入来访人员身份证'
                    oninput='if(value.length>18)value=value.slice(0,18)'
                    class='formText'
                  ></el-input>
                </el-form-item>
              </li>
              <li class='verDiv'>
                <h5>联系电话</h5>
                <el-form-item prop='phone'>
                  <el-input
                    type='number'
                    v-model='form.phone'
                    placeholder='请输入来访人员联系电话'
                    oninput='if(value.length>11)value=value.slice(0,11)'
                    class='formText'
                  ></el-input>
                  <el-button
                    @click='btnVerCode'
                    class='btnVerCode'
                    :disabled='!this.canClick'
                  >{{verCodeText}}</el-button>
                </el-form-item>
              </li>
              <li>
                <h5>手机验证码</h5>
                <el-form-item prop='phone'>
                  <el-input
                    type='number'
                    v-model='form.verCode'
                    placeholder='请输入手机验证码'
                    class='formText'
                  ></el-input>
                </el-form-item>
              </li>
            </ul>
            <div class='rightNextBtn' @click='next'>
              <i class='el-icon-right'></i>
            </div>
          </el-form>
        </div>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import axios from 'axios'
export default {
  data () {
    return {
      responseObj:{},
      form: {
        name: '',
        phone: '',
        id: '',
        unit: '',
        verCode: ''
      },
      verCodeText: '获取验证码',
      totalTime: 60,
      canClick: true,
      rules: {
        name: [
          {
            required: true,
            message: '请输入访问人姓名',
            trigger: 'blur'
          },
          {
            min: 2,
            max: 10,
            message: '长度在2到10个字符',
            trigger: 'blur'
          }
        ],
        phone: [
          {
            required: true,
            message: '请输入访问电话',
            trigger: 'blur'
          },
          {
            min: 11,
            max: 11,
            message: '长度在11个字符',
            trigger: 'blur'
          },
          {
            pattern: /^1[345678]\d{9}$/,
            message: '请输入正确电话',
            trigger: 'blur'
          }
        ],
        id: [
          {
            required: true,
            message: '请输入身份证号码',
            trigger: 'blur'
          },
          {
            min: 15,
            max: 18,
            message: '长度在18个字符',
            trigger: 'blur'
          },
          {
            pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
            message: '请输入正确身份证号码',
            trigger: 'blur'
          }
        ],
        unit: [
          {
            required: true,
            message: '请输入公司名称',
            trigger: 'blur'
          },
          {
            min: 2,
            max: 20,
            message: '长度在20个字符',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  methods: {
    btnVerCode () {
      if (this.form.phone.length !== 11 || this.form.phone === '') {
        this.$alert('请输入正确手机号码', '提示', {
          confirmButtonText: '确定'
        })
      } else {
        if (!this.canClick) return // 改动的是这两行代码
        let param = new URLSearchParams()
        param.append('phoneNum', this.form.phone)
        axios({
          method: 'post',
          url: 'http://47.107.124.163:8081/note/getVerificationCode',
          data: param
        }).then(response => {
          console.log(response.data)
        })
        this.canClick = false
        this.verCodeText = this.totalTime + 's'
        let clock = window.setInterval(() => {
          this.totalTime--
          this.verCodeText = this.totalTime + 's'
          if (this.totalTime < 0) {
            window.clearInterval(clock)
            this.verCodeText = '重新发送'
            this.totalTime = 60
            this.canClick = true // 这里重新开启
          }
        }, 1000)
      }
    },
    next () {
      this.$refs.form.validate(valid => {
        if (!valid) {
          return 0
        } else {
          let param = new URLSearchParams()
          param.append('visitorName', this.form.name)
          param.append('phoneNum', this.form.phone)
          param.append('cardType', '1')
          param.append('cardNum', this.form.id)
          param.append('enterpriseName', this.form.unit)
          param.append('vCode', this.form.verCode)
          axios({
            method: 'post',
            url: '/manager/visit/register',
            data: param
          })
            .then(response => {
              localStorage.setItem('visitPhone', this.phone)
              var data = response.data
              var obj = {}
              obj['phoneNum'] = this.form.phone
              if (data.code !== 1) {
                this.$alert('服务器开小差了', '提示', {
                  confirmButtonText: '确定'
                })
              } else {
                this.responseObj = response.data
                console.log(this.responseObj)
                localStorage.setItem('responseObj', this.responseObj)
                this.$router.push({ name: 'applyEdit', params: obj })
              }
            })
            .catch(() => {
              let clock = window.setInterval(() => {
                this.$alert('服务器开小差了，请重试', '提示', {
                  confirmButtonText: '确定'
                })
                window.clearInterval(clock)
              }, 2000)
            })
        }
      })
    }
  }
}
</script>

<style scoped>
.img1 {
  width: 100px;
  height: auto;
  display: block;
}
</style>

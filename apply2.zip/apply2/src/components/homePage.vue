<template>
  <div>
    <el-container>
      <el-main>
        <div class="add">
          <div class="top-nav">
            <a @click="allListLoad(0)" :class="{active:pageIndex === 0}">
              <h5>{{wait_totalcount}}</h5>待审批
            </a>
            <a @click="allListLoad(1)" :class="{active:pageIndex === 1}">
              <h5>{{already_totalcount}}</h5>已审批
            </a>
          </div>
          <!-- 待审批 -->
          <div v-if="pageIndex === 0" class="box">
            <div
              v-for="(item, index) in await_visitorDatas"
              :key="index"
              @click="goVisitorDetail(item.applicantId)"
            >
              <h3>{{title_await[index]}}</h3>
              <div class="lableLine">
                <small>{{item.corporateName}}</small>
              </div>
              <p>
                <strong>来访人员</strong>
                {{getVisitPerson(item.visitors)}}
              </p>
              <p>
                <strong>接洽人员</strong>
                {{item.approverName}}（{{item.approverBranch}})
              </p>
              <p>
                <strong>来访时间</strong>
                {{item.visitTime}}
              </p>
            </div>
          </div>
          <!-- 已审批 -->
          <div v-if="pageIndex === 1" class="box boxActice">
            <div
              v-for="(item, index) in already_visitorDatas"
              :key="index"
              @click="goVisitorDetail(item.applicantId)"
            >
              <h3>{{title_already[index]}}</h3>
              <div class="lableLine">
                <small>{{item.corporateName}}</small>
              </div>
              <p>
                <strong>来访人员</strong>
                {{getVisitPerson(item.visitors)}}
              </p>
              <p>
                <strong>接洽人员</strong>
                {{item.approverName}}（{{item.approverBranch}})
              </p>
              <p>
                <strong>来访时间</strong>
                {{item.visitTime}}
              </p>
            </div>
          </div>

          <div class="rightNextBtn" @click="toApplyEdit">
            <i class="el-icon-plus"></i>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "visitorHomePage",
  data() {
    return {
      responseObj: "",
      visitorId: "",
      form: {
        name: "",
        number: ""
      },
      params: {
        visitorId: "",
        state: ""
      },
      pageIndex: 0,
      await_visitorDatas: [],
      already_visitorDatas: [],
      title_await: [],
      title_already: [],
      wait_totalcount: 0,
      already_totalcount: 0
    };
  },
  mounted() {
    this.responseObj = localStorage.getItem("responseObj");
    this.visitorId = localStorage.getItem("visitorId");
    this.allListLoad(0);
    this.allListLoad(1);
  },
  methods: {
    getVisitPerson(val) {
      let result = "";
      for (let i = 0; i < val.length; i++) {
        if (i === 0) {
          result = val[i];
        } else {
          result += `,${val[i]}`;
        }
      }
      return result;
    },
    allListLoad(val) {
      const self = this;
      if (val === 0) {
        self.params.visitorId = self.visitorId;
        self.params.state = "stay";
        self.pageIndex = 0;
        axios({
          method: "post",
          url: "/operation/visitor/applys",
          headers: {
            "Content-Type": " application/json;charset=UTF-8"
          },
          data: JSON.stringify(self.params)
        })
          .then(res => {
            if (res.data.code === "0") {
              self.await_visitorDatas = res.data.data;
              self.wait_totalcount = res.data.data.length; // 总数
              for (let i in self.await_visitorDatas) {
                var status = self.await_visitorDatas[i].status; // 公司名称
                self.title_await.push(status);
              }
            }
          })
          .catch(res => {});
      } else {
        self.params.visitorId = self.visitorId;
        self.params.state = "already";
        self.pageIndex = 1;
        axios({
          method: "post",
          url: "/operation/visitor/applys",
          headers: {
            "Content-Type": " application/json;charset=UTF-8"
          },
          data: JSON.stringify(self.params)
        })
          .then(res => {
            if (res.data.code === "0") {
              self.already_visitorDatas = res.data.data;
              self.already_totalcount = res.data.data.length; // 总数
              for (let i in self.already_visitorDatas) {
                var status = self.already_visitorDatas[i].status; // 公司名称
                self.title_already.push(status);
              }
            }
          })
          .catch(res => {});
      }
    },

    goVisitorDetail(id) {
      const ids = id;
      // this.$router.push('/applyDetail')
      this.$router.push({
        name: "applyDetail",
        params: {
          id: ids
        }
      });
    },
    toApplyEdit() {
      var obj = this.$route.params;
      this.$router.push({ name: "applyEdit", params: obj });
      // this.$router.push('/applyEdit')
    }
  }
};
</script>

<style scoped>
.lableLine {
  width: 100%;
  clear: both;
  margin: 5px 0 15px 0;
  overflow: hidden;
}
.lableLine small {
  font-size: 12px;
  color: #fff;
  padding: 3px 8px;
  border: 1px solid #ffc130;
  border-radius: 20px;
  background: #ffc130;
}
.box {
  padding: 0;
  margin: 68px 0 42px 0;
}
.box > div {
  padding: 20px 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
  margin-bottom: 15px;
  position: relative;
}
.box > div h3 {
  font-size: 17px;
  line-height: 26px;
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}
.box > div p {
  position: relative;
  padding: 0 0 0 70px;
  color: #666;
  margin: 5px 0;
}
.box > div p strong {
  position: absolute;
  top: 0;
  left: 0;
  color: #333;
}
.box-foot {
  overflow: hidden;
  margin-top: 10px;
}
.box.boxActice > div h2 {
  position: absolute;
  top: 0;
  right: 10px;
  font-size: 14px;
  color: #fff;
  background: #486bfc;
  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
  padding: 3px 16px;
}
.box.boxActice > div h2.rejectLable {
  background: #ed3012;
}
.box.boxOverTime > div {
  opacity: 0.7;
}
.top-nav {
  position: fixed;
  top: 0;
  left: 0;
  border-bottom: 1px solid #ddd;
  background: rgba(255, 255, 255, 0.97);
  width: 100%;
  overflow: hidden;
  z-index: 9;
}
.top-nav a {
  width: 50%;
  float: left;
  display: block;
  text-align: center;
  padding: 8px 0 10px 0;
  position: relative;
  color: #777;
}
.top-nav a h5 {
  font-size: 16px;
  line-height: 28px;
  color: #777;
}
.top-nav a.active,
.top-nav a.active h5 {
  color: #486bfc;
}
.top-nav a.active:after {
  width: 50px;
  height: 4px;
  background: #486bfc;
  position: absolute;
  bottom: 0;
  left: 50%;
  margin-left: -25px;
  content: "";
}
</style>

<template>
  <div class="app1">
    <i class="topBg"></i>
    <div class="detailHead">
      <span class="logoImg">
        <img src="./../assets/logo.png" />
      </span>
      <h3>{{detailData.visitor}}</h3>
      <strong class="telPhone">{{detailData.visitorPhoneNum}}</strong>
      <ul class="visitorList">
        <li>
          <span>证件号码</span>
          {{detailData.visitorCardNum}}
        </li>
        <li>
          <span>单位名称</span>
          {{detailData.corporateName}}
        </li>
      </ul>
    </div>
    <div class="visitorBox">
      <h4>访问信息</h4>
      <ul class="visitorList">
        <li>
          <span>访问时间</span>
          {{detailData.visitorTime}}
        </li>
        <li>
          <span>来访事由</span>
          {{detailData.reason}}
        </li>
        <li>
          <span>携带物品</span>
          {{(detailData.goods)}}
        </li>
        <li>
          <span>车牌号码</span>
          {{detailData.carNum}}
        </li>
        <li>
          <span>同行人员</span>
          {{detailData.parLength}}
        </li>
      </ul>
    </div>
    <div class="visitorBox">
      <h4>接洽人信息</h4>
      <div class="receive">
        <img src="./../assets/logo.png" />
        <h3>{{detailData.approverName}}</h3>
        <p>{{detailData.approverBranch}}</p>
      </div>
    </div>
    <div class="visitorBox lastDiv">
      <h4>审批流程</h4>
      <ul class="approvalLine">
        <li class="agree">
          <h3>{{detailData.visitor}}</h3>
          <span>07-29</span>
          <p>提交申请</p>
        </li>
        <li class="reject">
          <h3>{{detailData.approverName}}</h3>
          <span>07-30</span>
          <p>{{detailData.approverBranch}}</p>
          <strong></strong>
        </li>
        <li>
          <h3>{{detailData.status}}</h3>
        </li>
      </ul>
    </div>
    <div class="bottomnav" @click="toHomePage">
      <a class="returnIndex">返回访客首页</a>
    </div>
  </div>
</template>
<script>
import axios from "axios";
export default {
  name: "visitorHomePage",
  data() {
    return {
      uid: "",
      detailData: {},
      parLength: 0
    };
  },
  mounted: function() {
    this.uid = this.$route.params.id;
    this.loadListFunction();
  },
  methods: {
    loadListFunction() {
      const self = this;
      let params = {};
      params["applicationId"] = self.uid;
      self
        .$axios({
          method: "post",
          url: "/operation/visitor/appDetail",
          headers: {
            "Content-Type": " application/json;charset=UTF-8"
          },
          data: JSON.stringify(params)
        })
        .then(res => {
          self.detailData = res.data.data;
          self.parLength = res.data.data.visitors.length;
          self.detailData.goods = res.data.data.goods
            .replace("[", "")
            .replace("]", "");
          if (res.data.code !== "0") {
            this.$alert("网络开小差了,请重试", "提示", {
              confirmButtonText: "确定",
              callback: action => {
                this.$router.push("/homePage");
              }
            });
          }
        })
        .catch(res => {});
    },
    toHomePage() {
      this.$router.push("/homePage");
    }
  }
};
</script>

<style scoped>
.topBg {
  width: 100%;
  height: 180px;
  position: absolute;
  top: 0;
  left: 0;
  background: -webkit-linear-gradient(#486bfc, #7e44fc); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(#486bfc, #7e44fc); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(#486bfc, #7e44fc); /* Firefox 3.6 - 15 */
  background: -ms-linear-gradient(#486bfc, #7e44fc);
  background: linear-gradient(#486bfc, #7e44fc); /* 标准的语法 */
  z-index: 1;
  border-bottom-left-radius: 16px;
  border-bottom-right-radius: 16px;
}
.detailHead {
  width: 94%;
  height: auto;
  margin: 70px auto 15px auto;
  border-radius: 8px;
  background: #fff;
  position: relative;
  z-index: 6;
  text-align: center;
  padding: 45px 0 0 0;
}
.detailHead img {
  width: 70px;
  height: 70px;
  display: block;
  position: absolute;
  top: -35px;
  left: 50%;
  margin-left: -35px;
}
.detailHead h3 {
  font-size: 20px;
  line-height: 30px;
  color: #333;
  font-weight: bold;
  padding: 0 15px 5px 15px;
}
.detailHead .visitorList {
  padding: 10px 0 0 0;
  margin-top: 15px;
}
.detailHead .visitorList li {
  text-align: left;
}
.detailHead .telPhone {
  padding: 0 0 0 26px;
  background: url(./../assets/phone01.png) no-repeat left center;
  background-size: 18px auto;
}
.visitorBox {
  background: #fff;
  margin-bottom: 10px;
}
.visitorBox h4 {
  font-size: 16px;
  line-height: 40px;
  color: #486bfc;
  padding: 10px 15px;
}
.visitorList li {
  position: relative;
  padding: 13px 15px 13px 100px;
  border-bottom: 1px solid #eee;
  min-height: 47px;
}
.visitorList li span {
  position: absolute;
  top: 13px;
  left: 15px;
  font-weight: bold;
}
.receive {
  position: relative;
  padding: 0 0 20px 90px;
  color: #999;
  margin: 10px 0 0 0;
  overflow: hidden;
  min-height: 60px;
}
.receive img {
  width: 50px;
  height: 50px;
  position: absolute;
  top: 0;
  left: 25px;
}
.receive h3 {
  font-size: 16px;
  line-height: 30px;
  color: #333;
}
.approvalLine {
  position: relative;
  padding: 20px 0;
}
.approvalLine li {
  padding-bottom: 26px;
  color: #999;
  position: relative;
  padding: 0 0 26px 100px;
}
.approvalLine li:before {
  content: "";
  width: 20px;
  height: 20px;
  background: #eee;
  border-radius: 30px;
  position: absolute;
  top: 0;
  left: 50px;
}
.approvalLine li:after {
  content: "";
  position: absolute;
  top: 20px;
  left: 60px;
  width: 2px;
  height: 100%;
  background: #eee;
}
.approvalLine li h3 {
  color: #333;
  font-size: 16px;
  padding: 0 60px 6px 0;
}
.approvalLine li span {
  position: absolute;
  top: 0;
  right: 15px;
  font-size: 12px;
}
.approvalLine li.agree:after,
.approvalLine li.agree:before {
  background: #486bfc;
}
.approvalLine li.reject:after,
.approvalLine li.reject:before {
  background: #ed3012;
}
.approvalLine li.agree h3,
.approvalLine li.reject h3 {
  font-weight: bold;
}
.bottomnav {
  position: fixed;
  bottom: 0;
  left: 0;
  border-top: 1px solid #eee;
  background: rgba(255, 255, 255, 0.97);
  width: 100%;
  overflow: hidden;
  z-index: 9;
  text-align: center;
  display: block;
  padding: 13px;
}
.bottomnav a {
  padding: 0 0 0 26px;
  background: url(./../assets/home01.png) no-repeat left center;
  background-size: 18px auto;
  color: #666;
  width: 100%;
}
.lastDiv {
  margin-bottom: 48px;
}
</style>

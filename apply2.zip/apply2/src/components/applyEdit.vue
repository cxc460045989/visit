<template>
  <div class='bgWhite'>
    <el-container>
      <el-main>
        <div class='formBoxReg'>
          <div class='preBtn' @click='nextHomePage' v-if='phoneNumber == 0'>
            <i class='el-icon-arrow-left'></i>
          </div>

          <h1>欢迎来访</h1>
          <h4>请填写您的来访信息</h4>
          <el-form :model='form' :rules='rules' ref='form'>
            <ul class='formListReg'>
              <li>
                <h5>访问时间</h5>
                <div class='dateGround'>
                  <el-form-item prop='dataDateStart'>
                    <el-date-picker
                      v-model='form.dataDateStart'
                      type='date'
                      :picker-options='pickerStart'
                      placeholder='来访开始时间'
                    ></el-date-picker>
                  </el-form-item>
                  <span class='dateRange'>-</span>
                  <el-form-item prop='dataDateEnd'>
                    <el-date-picker
                      @change='changetime'
                      v-model='form.dataDateEnd'
                      type='date'
                      :picker-options='pickerEnd'
                      placeholder='来访结束时间'
                    ></el-date-picker>
                  </el-form-item>
                </div>
                <span class='font_time'>{{'共'+ form.days +'天'}}</span>
              </li>
              <li>
                <h5>来访事由</h5>
                <el-form-item prop='radio'>
                  <el-radio-group v-model='form.radio'>
                    <el-radio-button label='上班'></el-radio-button>
                    <el-radio-button label='例行检查'></el-radio-button>
                    <el-radio-button label='交流学习'></el-radio-button>
                    <el-radio-button label='面试应聘'></el-radio-button>
                    <el-radio-button label='其他'></el-radio-button>
                  </el-radio-group>
                </el-form-item>
              </li>
              <li>
                <h5>
                  携带物品
                  <small>(选填)</small>
                </h5>
                <el-form-item>
                  <el-checkbox-group v-model='form.checklist'>
                    <el-checkbox-button v-for='item in form.list' :label='item' :key='item'>{{item}}</el-checkbox-button>
                  </el-checkbox-group>
                </el-form-item>
              </li>
              <li>
                <h5>
                  是否开车出入
                  <small>(选填)</small>
                </h5>
                <el-switch v-model='form.value'></el-switch>
              </li>
              <!-- <li>
                <h5>车辆类型</h5>
                 <el-form-item prop='id'>
                <el-input type='text' v-model='form.id' placeholder='请输入车辆类型'  class='formText'></el-input>
                </el-form-item>
              </li>-->
              <li v-if='form.value'>
                <h5>车牌号码</h5>
                <el-form-item prop='content'>
                  <el-input
                    type='textarea'
                    :rows='3'
                    resize='none'
                    maxlength='100'
                    placeholder='请输入车牌号码,多个车牌号请用逗号隔开'
                    v-model='form.content'
                  ></el-input>
                </el-form-item>
              </li>
              <li>
                <span style='font-size: 15px;font-weight: bold;'>同行人信息</span>
                <span>(选填)</span>
                <div class='labelList'>
                  <span class='active' @click='adds'>
                    <i class='el-icon-plus'></i> 添加
                  </span>
                </div>
                <div class='parterList' v-for='(list,i) in form.parterlist' :key='i'>
                  <div>
                    <h3>{{'同行人'+ (i+1)}}</h3>
                    <a class='deteBox'>
                      <img src='./../assets/dele02.png' @click='dels(list,i)' />
                    </a>
                    <ul>
                      <li>
                        <el-form-item prop='followerName'>
                          <el-input
                            type='text'
                            v-model='list.followerName'
                            placeholder='请输入同行人姓名'
                            class='formText'
                          ></el-input>
                        </el-form-item>
                      </li>
                      <li>
                        <el-form-item prop='phoneNum'>
                          <el-input
                            type='number'
                            v-model='list.phoneNum'
                            placeholder='请输入同行人电话'
                            class='formText'
                          ></el-input>
                        </el-form-item>
                      </li>
                      <li>
                        <el-form-item prop='cardNum'>
                          <el-input
                            v-model='list.cardNum'
                            placeholder='请输入同行人身份证号码'
                            class='formText'
                          ></el-input>
                        </el-form-item>
                      </li>
                    </ul>
                  </div>
                </div>
              </li>
            </ul>

            <div @click='next' class='rightNextBtn'>
              <i class='el-icon-right'></i>
            </div>
          </el-form>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data () {
    return {
      anull: true,
      applyObj: {},
      phoneNumber: 0,
      pickerStart: {
        disabledDate (time) {
          return time.getTime() + 3600 * 1000 * 24 < Date.now()
        }
      },
      pickerEnd: {
        disabledDate (time) {
          return time.getTime() + 3600 * 1000 * 24 < Date.now()
        }
      },
      form: {
        applyObj: {},
        loginPhoneNumber: '',
        parterlist: [],
        days: '0',
        name: '',
        phone: '',
        id: '',
        unit: '',
        content: '',
        dataDateStart: '',
        dataDateEnd: '',
        radio: '上班',
        value: false,
        checklist: [],
        list: ['电脑', '行李箱', '工具', '背包', '摄影器材', '食品', '其他物品']
      },
      rules: {
        dataDateStart: [
          {
            type: 'date',
            required: true,
            message: '请选择来访开始时间',
            trigger: 'change'
          }
        ],
        dataDateEnd: [
          {
            type: 'date',
            required: true,
            message: '请选择来访结束时间',
            trigger: 'change'
          }
        ],
        radio: [
          {
            required: true,
            message: '请选择来访事由',
            trigger: 'change'
          }
        ],
        content: [
          {
            required: true,
            message: '请填写车牌号,多个车牌请用逗号隔开',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  mounted () {
    // this.loginPhoneNumber = localStorage.getItem('phoneNumber')
    this.phoneNumber = this.$route.params.phoneNum || 0
  },
  methods: {
    addObj () {
      const obj = {
        followerName: '',
        phoneNum: '',
        cardNum: ''
      }
      this.form.parterlist.push(obj)
    },
    adds () {
      this.addObj()
    },
    dels (list, i) {
      this.form.parterlist = this.form.parterlist.filter(item => item !== list)
    },
    changetime () {
      const start = this.form.dataDateStart
      const end = this.form.dataDateEnd
      const bb = Math.round(end / 1000) - Math.round(start / 1000)
      this.form.days = bb / Number(60 * 60 * 24) + 1
    },
    next () {
      this.$refs.form.validate(valid => {
        if (!valid) {
          return 0
        } else {
          if (this.form.dataDateEnd < this.form.dataDateStart) {
            let clock = window.setInterval(() => {
              this.$alert('来访结束时间不能小于开始时间，请重新填写', '提示', {
                confirmButtonText: '确定'
              })
              window.clearInterval(clock)
            }, 3000)
          } else {
            const parArr = this.form.parterlist
            if (parArr.length > 0) {
              for (let i = 0; i < parArr.length; i++) {
                if (
                  parArr[i].followerName === '' ||
                  parArr[i].phoneNum === '' ||
                  parArr[i].cardNum === ''
                ) {
                  this.anull = true
                  let clock = window.setInterval(() => {
                    this.$alert('同行人信息不完整，请补充填写', '提示', {
                      confirmButtonText: '确定'
                    })
                    window.clearInterval(clock)
                  }, 300)
                  break
                } else if (
                  parArr[i].followerName.length < 2 ||
                  parArr[i].phoneNum.length < 11 ||
                  (parArr[i].cardNum.length !== 15 && parArr[i].cardNum.length !== 18)
                ) {
                  this.anull = true
                  if (parArr[i].followerName.length < 2) {
                    let clock = window.setInterval(() => {
                      this.$alert('同行人姓名信息不完整，请补充填写', '提示', {
                        confirmButtonText: '确定'
                      })
                      window.clearInterval(clock)
                    }, 300)
                  } else if (parArr[i].phoneNum.length < 11) {
                    let clock = window.setInterval(() => {
                      this.$alert(
                        '同行人手机号码信息不完整，请补充填写',
                        '提示',
                        {
                          confirmButtonText: '确定'
                        }
                      )
                      window.clearInterval(clock)
                    }, 300)
                  } else {
                    let clock = window.setInterval(() => {
                      this.$alert(
                        '同行人身份证信息不完整，请补充填写',
                        '提示',
                        {
                          confirmButtonText: '确定'
                        }
                      )
                      window.clearInterval(clock)
                    }, 300)
                  }
                } else {
                  if (!/^1[345678]\d{9}$/.test(parArr[i].phoneNum)) {
                    let clock = window.setInterval(() => {
                      this.$alert('请填写正确的同行人手机号码信息', '提示', {
                        confirmButtonText: '确定'
                      })

                      window.clearInterval(clock)
                    }, 300)
                  } else if (
                    !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(
                      parArr[i].cardNum
                    )
                  ) {
                    let clock = window.setInterval(() => {
                      this.$alert('请填写正确的同行人身份证信息', '提示', {
                        confirmButtonText: '确定'
                      })
                      window.clearInterval(clock)
                    }, 300)
                  } else {
                    this.anull = false
                  }
                }
              }
              if (this.anull) {
                return 0
              } else {
                this.applys()
              }
            } else {
              this.applys()
            }
          }
        }
      })
    },
    applys () {
      this.applyObj['beginDate'] = this.form.dataDateStart
      this.applyObj['endDate'] = this.form.dataDateEnd
      this.applyObj['reason'] = this.form.radio
      this.applyObj['goods'] = this.form.checklist
      this.applyObj['carNum'] = this.form.content
      this.applyObj['carType'] = this.form.value === false ? '0' : '1'
      this.applyObj['compInfo'] = this.form.parterlist
      this.applyObj['phoneNum'] = this.$route.params['phoneNum']
      this.$router.push({ name: 'applyCommit', params: this.applyObj })
    },
    nextHomePage () {
      this.$router.push('/homePage')
    }
  }
}
</script>

<style scoped>
html,
body {
  color: #2c3e50;
  background: #fff !important;
}
h5 small {
  color: #999;
  font-size: 12px;
  margin-left: 10px;
}

.preBtn {
  border: 1px solid #486bfc;
  color: #486bfc;
  width: 28px;
  height: 28px;
  line-height: 28px;
  border-radius: 50%;
  display: block;
  text-align: center;
  font-size: 18px;
}
.font_time {
  display: block;
  position: absolute;
  top: 15px;
  right: 0;
  color: #999;
}
.el-date-editor--daterange.el-input,
.el-date-editor--daterange.el-input__inner,
.el-date-editor--timerange.el-input,
.el-date-editor--timerange.el-input__inner {
  width: 100%;
  position: relative;
}
.el-range-editor.el-input__inner {
  padding: 0;
}
.el-input__inner {
  border-radius: 0px;
  border: 0;
  border-bottom: 1px solid;
}
.labelList {
  overflow: hidden;
  margin-top: 8px;
}
.labelList span {
  border-radius: 20px;
  padding: 8px 22px;
  background: #eee;
  margin: 8px 10px 5px 0;
  display: inline-block;
  color: #666;
}
.labelList span.active {
  background: #486bfc;
  color: #fff;
}
.parterList > div {
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.08);
  padding: 10px 15px 22px 15px;
  position: relative;
  margin: 15px 0 0 0;
  border-radius: 6px;
}
.parterList > div h3 {
  font-size: 14px;
  line-height: 40px;
  position: relative;
  padding-left: 12px;
  color: #486bfc;
  margin-bottom: 10px;
}
.parterList > div h3:before {
  width: 3px;
  height: 10px;
  content: '';
  background: #486bfc;
  display: block;
  position: absolute;
  top: 50%;
  left: 0;
  margin-top: -5px;
}

.parterList > div .deteBox {
  width: 30px;
  height: 30px;
  border-radius: 20px;
  display: block;
  padding: 7px;
  position: absolute;
  top: 5px;
  right: 10px;
}
.parterList > div .el-form-item {
  margin-bottom: 0;
}
.parterList > div li {
  margin: 0;
}
</style>

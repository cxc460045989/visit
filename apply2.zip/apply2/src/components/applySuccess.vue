<template>
  <!-- 第四步 -->
  <div class="formBox end">
    <span class="endStateimg"></span>
    <h3>恭喜你，申请提交成功</h3>
    <p>需1-2个工作日进行审批</p>
    <p>请耐心等待答复</p>
    <a class="btn" @click="btnDetail">查看详情</a>
  </div>
</template>
<script>
import axios from 'axios'
export default {
  methods: {
    btnDetail () {
      var obj = this.$route.params
      const ids = obj.applicationId
      this.$router.push({ name: 'applyDetail', params: { id: ids } })
    }
  }
}
</script>

<style scoped>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  max-width: 100%;
  /* height: 100%; */
  color: #2c3e50;
  background-color: white;
}
/* 提交成功 */
.formBox.end {
  overflow: hidden;
  text-align: center;
}
.formBox.end p {
  color: #999;
  padding: 0;
}
.formBox.end .btn {
  width: 50%;
  border-color: #486bfc;
  color: #fff;
  background: #486bfc;
  margin: 50px auto;
  float: inherit;
  display: block;
}
.formBox.end h3 {
  font-size: 18px;
  padding: 20px 0;
}
.endStateimg {
  width: 80px;
  height: 80px;
  background: url(./../assets/sucIcon.png) no-repeat center;
  background-size: contain;
  display: block;
  margin: 50px auto 15px auto;
}
</style>

<template>
  <div class='app'>
    <h2 class='loginTitle'>访客管理系统</h2>
    <div class='loginMain'>
      <div class='loginTop'>
        <p style='margin-left:30%'>登录</p>
        <p @click='toRegister' style='margin-right:30%;'>注册</p>
      </div>
      <el-input type='number' class='regCodeImg' v-model='phone' placeholder='请输入手机号'></el-input>
      <div class='identCodeDiv'>
        <el-input type='number' class='loginImg' v-model='verCode' placeholder='请输入验证码'></el-input>
        <div @click='btnVerCode' class='verCode'>{{verCodeText}}</div>
      </div>
      <div class='login'>
        <el-button @click='btnLogin'>登录</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
export default {
  data () {
    return {
      responseId: '',
      responseObj:{},
      phone: '',
      verCode: '',
      verCodeText: '获取验证码',
      totalTime: 60,
      canClick: true,
      visitedObj: {},
      rules: {
        phone: []
      }
    }
  },
  mounted () {
    localStorage.setItem('visitId', this.$route.query.id)
    localStorage.setItem('visitName', this.$route.query.name)
  },
  methods: {
    btnVerCode () {
      if (this.phone.length !== 11 || this.phone === '') {
        this.$alert('请输入正确手机号码', '提示', {
          confirmButtonText: '确定'
        })
      } else {
        if (!this.canClick) return // 改动的是这两行代码
        let param = new URLSearchParams()
        param.append('phoneNum', this.phone)
        axios({
          method: 'post',
          url: 'http://47.107.124.163:8081/note/getVerificationCode',
          data: param
        }).then(response => {})
        this.canClick = false
        this.verCodeText = this.totalTime + 's'
        let clock = window.setInterval(() => {
          this.totalTime--
          this.verCodeText = this.totalTime + 's'
          if (this.totalTime < 0) {
            window.clearInterval(clock)
            this.verCodeText = '重新发送'
            this.totalTime = 60
            this.canClick = true
          }
        }, 1000)
      }
    },
    toRegister () {
      this.$router.push('/register')
    },
    btnLogin () {
      if (this.phone === '') {
        this.$alert('请输入手机号码', '提示', {
          confirmButtonText: '确定'
        })
      } else if (this.verCode === '' || this.verCode.length < 4) {
        this.$alert('请输入正确验证码', '提示', {
          confirmButtonText: '确定'
        })
      } else {
        let param = new URLSearchParams()
        param.append('phoneNum', this.phone)
        param.append('vCode', this.verCode)
        axios({ 
          method: 'post',
          url: '/manager/visit/login',
          data: param
        })
          .then(response => {
            localStorage.setItem('visitPhone', this.phone)
            if (response.data.code === 0) {
              let clock = window.setInterval(() => {
                this.$alert(response.data.msg, '提示', {
                  confirmButtonText: '确定'
                })
                window.clearInterval(clock)
              }, 3000)
            } else {
              this.responseObj= response.data
              console.log(this.responseId)
              localStorage.setItem('responseObj',this.responseObj)
              localStorage.setItem('visitorId',response.data.date['visitorId'])
              this.$router.push({ name: 'homePage', params: this.responseObj })
            }
          })
          .catch(error => {
            let clock = window.setInterval(() => {
              this.$alert('服务器开小差了，请重试', '提示', {
                confirmButtonText: '确定'
              })
              window.clearInterval(clock)
            }, 3000)
            console.log(error)
          })
      }
    }
  }
}
</script>

<style scoped>
.app {
  height: 100%;
  background: url('./../assets/BgLogin.png') no-repeat center;
  background-size: cover;
  width: 100%;
  position: fixed;
  max-width: 640px;
}
.loginTitle {
  text-align: center;
  font-size: 30px;
  color: #fff;
  line-height: 50px;
  margin: 20% 0 50px 0;
  display: block;
}
.loginMain {
  display: flex;
  flex-direction: column;
  width: 84%;
  background-color: rgb(207, 207, 207, 0.2);
  border-radius: 26px;
  margin: 0 auto;
  padding: 20px 30px;
}

.loginTop {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  width: 100%;
  line-height: 40px;
  font-size: 18px;
  color: white;
  height: 50px;
  margin-bottom: 30px;
}
.loginTop p {
  text-shadow: 0 0 10px rgba(0, 0, 0, 0.4);
}
.loginTop p:nth-child(1) {
  background: url('./../assets/WechatIMG5.png') no-repeat right 30px;
  background-size: auto 15px;
}

.identCodeDiv {
  display: flex;
  justify-content: flex-start;
  width: 100%;
  margin-top: 20px;
}
.login .el-button {
  text-align: center;
  outline: 0;
  margin: 0;
  -webkit-transition: 0.1s;
  transition: 0.1s;
  font-weight: 500;
  padding: 12px 20px;
  font-size: 18px;
  margin: 35px auto;
  border-radius: 30px;
  color: white;
  border: 0;
  width: 100%;
  background-color: #08b6ff;
}
.verCode {
  border: none;
  background: white;
  width: 50%;
  font-size: 12px;
  color: #1728e8;
  border-radius: 0px 20px 20px 0px;
  line-height: 42px;
  text-align: center;
}
</style>

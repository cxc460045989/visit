<template>
  <div class='bgWhite'>
    <el-container>
      <el-main> 
        <div  class='formBoxReg'>
          <div class='preBtn' @click='back'>
            <i class='el-icon-arrow-left'></i>
          </div>
          <h1>欢迎来访</h1>
          <h4>请填写被访问人的资料信息</h4>

          <el-form :model='form' :rules='rules' ref='form'>
            <ul class='formListReg'>
              <li>
                <h5>姓名</h5>
                <el-form-item prop='name'>
                  <el-input
                    v-model='form.name'
                    type='text'
                    placeholder='请输入被访问人姓名'
                    class='formText'
                  ></el-input>
                </el-form-item>
              </li>
              <li>
                <h5>统一认证号</h5>
                <el-form-item prop='number'>
                  <el-input
                    v-model='form.number'
                    type='number'
                    oninput='if(value.length>9)value=value.slice(0,9)'
                    placeholder='请输入被访问人统一认证号'
                    class='formText'
                  ></el-input>
                </el-form-item>
              </li>
            </ul>
            <el-button round class='btn' type='primary' @click='sets'>提 交 申 请</el-button>
          </el-form>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
import axios from 'axios'
import moment from 'moment'
export default {
  data () {
    return {
      visitorObj: {},
      form: {
        name: '',
        number: ''
      },
      rules: {
        name: [
          {
            required: true,
            message: '请输入被访问人信息',
            trigger: 'blur'
          },
          {
            min: 2,
            max: 10,
            message: '长度在2到10个字符',
            trigger: 'blur'
          }
        ],
        number: [
          {
            required: true,
            message: '请输入被访问人统一认证号',
            trigger: 'blur'
          },
          {
            min: 9,
            max: 9,
            message: '长度在9个字符',
            trigger: 'blur'
          },
          {
            pattern: /^[0-9]{9}/,
            message: '请输入正确统一认证号',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  mounted () {
    this.form.name = localStorage.getItem('visitName')
    if (this.form.name === 'undefined') this.form.name = ''
    this.form.number = localStorage.getItem('visitId') || ''
    this.visitorObj = localStorage.getItem('responseObj')
  },
  methods: {
    onSubmit () {
      let param = {}
      param.phoneNum = localStorage.getItem('visitPhone')
      param.approverId = this.form.number
      param.approverName = this.form.name
      let start = new Date(this.$route.params['beginDate'])
      start = moment(start).format('YYYY-MM-DD')
      let end = new Date(this.$route.params['endDate'])
      end = moment(end).format('YYYY-MM-DD')
      param.enterTime = start
      param.leaveTime = end
      param.reason = this.$route.params['reason']
      param.follows = this.$route.params['compInfo']
      param.carType = this.$route.params['carType']
      param.goods = this.$route.params['goods']
      param.carNum = this.$route.params['carNum']
      axios({
        method: 'post',
        url: '/operation/visitor/insert',
        data: param
      }).then(response => {
        if (response.data.code !== '1') {
          this.$alert('服务器开小差了', '提示', {
            confirmButtonText: '确定'
          })
        } else {
           this.$router.push({
                name: 'applySuccess',
                params: response.data.data 
              })
          let query = {}
          query['assignee'] = this.form.number
          query['applId'] = response.data.data.applicationId
          query['key'] = 'visitor-key-7'
          axios({
            headers: {
              'Content-Type': 'application/json'
            },
            method: 'post',
            url: 'https://zhl.lululuye.xyz/wpark_web/process/startProcess',
            data: query
          }).then(res => {
            if (res.data.status !== 200) {
              this.$alert('服务器开小差了', '提示', {
                confirmButtonText: '确定'
              })
            } else {
              const applicationId = response.data.applicationId
              this.$router.push({
                name: 'applySuccess',
                params: { id: applicationId }
              })
            }
          })
        }
      })
    },
    back () {
      this.$router.push('/applyEdit')
    },
    sets () {
      this.$refs.form.validate(valid => {
        if (!valid) {
          this.$alert('请正确输入被访人信息', '提示', {
            confirmButtonText: '确定'
          })
        } else {
          this.onSubmit()
        }
      })
    }
  }
}
</script>

<style scoped>
#app {
  background-color: #fff;
  color: #2c3e50;
}
.preBtn {
  border: 1px solid #486bfc;
  color: #486bfc;
  width: 28px;
  height: 28px;
  line-height: 28px;
  border-radius: 50%;
  display: block;
  text-align: center;
  font-size: 18px;
}
.btn {
  background: -webkit-linear-gradient(
    left top,
    #486bfc,
    #7e44fc
  ); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(
    bottom right,
    #486bfc,
    #7e44fc
  ); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(
    bottom right,
    #486bfc,
    #7e44fc
  ); /* Firefox 3.6 - 15 */
  background: -ms-linear-gradient(left top, #486bfc, #7e44fc);
  background: linear-gradient(bottom right, #486bfc, #7e44fc); /* 标准的语法 */

  width: 100%;
  color: #fff;
  padding: 15px 0;
  border-radius: 30px;
}
.formListReg {
  padding-bottom: 30px;
}
</style>

import Vue from 'vue'
import Router from 'vue-router'
import userLogin from '@/components/userLogin'
import register from '@/components/register'
import applyEdit from '@/components/applyEdit'
import applyCommit from '@/components/applyCommit'
import applySuccess from '@/components/applySuccess'
import applyDetail from '@/components/applyDetail'
import homePage from '@/components/homePage'




Vue.use(Router)

export default new Router({
  mode: 'hash',
  routes: [{
      path: '/',
      name: 'userLogin',
      component: userLogin
    },
    {
      path: '/register',
      name: 'register',
      component: register
    },
    {
      path: '/applyEdit',
      name: 'applyEdit',
      component: applyEdit
    },
    {
      path: '/applyCommit',
      name: 'applyCommit',
      component: applyCommit
    },
    {
      path: '/applySuccess',
      name: 'applySuccess',
      component: applySuccess
    },
    {
      path: '/applyDetail',
      name: 'applyDetail',
      component: applyDetail
    },
    {
      path: '/homePage',
      name: 'homePage',
      component: homePage
    },
  ]
})
